import { useEffect, useMemo, useRef, useState, type KeyboardEvent as ReactKeyboardEvent } from "react";
import type { ProjectGroup, Thread, WorkspaceKind } from "../../types/workspace";
import ProjectHomeView from "../project/ProjectHomeView";
import { FilePreviewThumbnail } from "./FilePreview";
import { MAX_ATTACHMENTS } from "../../utils/constants";
import { t } from "../../i18n";
import { showToast } from "../ui/Toast";
type AttachedFile = { name: string; type: string; base64: string; size: number };

type Props = {
  workspaceKind: WorkspaceKind;
  activeProject: ProjectGroup | null;
  generalThreads: Thread[];
  projectThreads: Thread[];
  sidebarView: "default" | "search" | "images" | "benchmark" | "dashboard";
  isSending: boolean;
  onOpenThread: (threadId: string) => void;
  onSubmitPrompt: (value: string) => void;
  onRenameThread?: (threadId: string, nextTitle: string) => void;
  onMoveThread?: (threadId: string, nextProjectId: string) => void;
  onRemoveFromProject?: (threadId: string) => void;
  onDeleteThread?: (threadId: string) => void;
  projectGroups?: ProjectGroup[];
  attachedFiles?: AttachedFile[];
  onAttachFiles?: (files: AttachedFile[]) => void;
};

function PlusIcon() {
  return (
    <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}

function MicIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M12 5a4 4 0 0 1 4 4v3a4 4 0 0 1-8 0V9a4 4 0 0 1 4-4z" />
      <path d="M19 11a7 7 0 0 1-14 0M12 18v3" />
    </svg>
  );
}

function WaveIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
      <rect x="4" y="10" width="2" height="4" rx="1" />
      <rect x="8" y="8" width="2" height="8" rx="1" />
      <rect x="12" y="6" width="2" height="12" rx="1" />
      <rect x="16" y="8" width="2" height="8" rx="1" />
    </svg>
  );
}

function stripMd(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, "")
    .replace(/`[^`]+`/g, "")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/\*([^*]+)\*/g, "$1")
    .replace(/^#+\s+/gm, "")
    .replace(/^[-*]\s+/gm, "")
    .replace(/\[\d+\]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function highlight(text: string, query: string): React.ReactNode {
  if (!query.trim()) return text;
  const escaped = query.replace(/[$()*+.?[\]^{|}]/g, "\\$&");
  const parts = text.split(new RegExp("(" + escaped + ")", "gi"));
  return parts.map((part, i) =>
    part.toLowerCase() === query.toLowerCase()
      ? <mark key={i} style={{ background: "#fef08a", color: "#78350f", borderRadius: 2, padding: "0 1px" }}>{part}</mark>
      : part
  );
}

function SearchView({
  threads,
  projectGroups,
  onOpenThread
}: {
  threads: Thread[];
  projectGroups?: ProjectGroup[];
  onOpenThread?: (threadId: string) => void;
}) {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const q = query.trim().toLowerCase();

  type SearchResult = {
    threadId: string;
    threadTitle: string;
    projectTitle?: string;
    matchContent: string;
  };

  const results: SearchResult[] = useMemo(() => {
    if (!q) return [];
    const out: SearchResult[] = [];
    for (const thread of threads) {
      const titleMatch = thread.title.toLowerCase().includes(q);
      const matchingMsg = thread.messages
        .filter(m => !m.isHidden && m.content?.trim())
        .find(m => m.content.toLowerCase().includes(q));
      if (!titleMatch && !matchingMsg) continue;
      const projectTitle = projectGroups?.find(p => p.id === thread.projectId)?.title;
      const raw = matchingMsg?.content ?? thread.title;
      const clean = stripMd(raw);
      const idx = clean.toLowerCase().indexOf(q);
      const start = Math.max(0, idx - 40);
      const excerpt = (start > 0 ? "..." : "") + clean.slice(start, start + 120) + (start + 120 < clean.length ? "..." : "");
      out.push({ threadId: thread.id, threadTitle: thread.title, projectTitle, matchContent: excerpt });
    }
    return out.slice(0, 50);
  }, [q, threads, projectGroups]);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", maxWidth: 720, margin: "0 auto", padding: "24px 20px 0", width: "100%" }}>
      <div style={{ position: "relative", marginBottom: 24 }}>
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.8"
          style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: "var(--text-sub)", pointerEvents: "none" }}>
          <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
        </svg>
        <input ref={inputRef} value={query} onChange={e => setQuery(e.target.value)}
          placeholder={t("home.searchPlaceholder")}
          style={{ width: "100%", padding: "12px 40px", borderRadius: 12, border: "1px solid var(--border)", fontSize: 14, color: "var(--text-main)", background: "var(--surface-1, #f9fafb)", outline: "none", boxSizing: "border-box" as const }} />
        {query && (
          <button type="button" onClick={() => setQuery("")}
            style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", border: "none", background: "none", cursor: "pointer", color: "var(--text-sub)", display: "flex", alignItems: "center" }}>
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        )}
      </div>
      <div style={{ flex: 1, overflowY: "auto" }}>
        {!q ? (
          <div style={{ textAlign: "center", padding: "48px 20px", color: "var(--text-soft)" }}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>⌕</div>
            <div style={{ fontSize: 14, fontWeight: 500 }}>{t("home.searchAll")}</div>
            <div style={{ fontSize: 13, marginTop: 6 }}>{t("home.searchHint")}</div>
          </div>
        ) : results.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 20px", color: "var(--text-soft)" }}>
            <div style={{ fontSize: 14 }}>{t("home.noResults").replace("{query}", query)}</div>
          </div>
        ) : (
          <div>
            <div style={{ fontSize: 12, color: "var(--text-sub)", marginBottom: 12 }}>{t("home.resultCount").replace("{count}", String(results.length))}</div>
            {results.map(r => (
              <button key={r.threadId} type="button" onClick={() => onOpenThread?.(r.threadId)}
                style={{ display: "block", width: "100%", textAlign: "left", padding: "12px 14px", marginBottom: 6, border: "1px solid var(--border)", borderRadius: 10, background: "var(--surface-1, #f9fafb)", cursor: "pointer" }}
                onMouseEnter={e => (e.currentTarget.style.background = "var(--surface-2, #f3f4f6)")}
                onMouseLeave={e => (e.currentTarget.style.background = "var(--surface-1, #f9fafb)")}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 5 }}>
                  {r.projectTitle && (
                    <span style={{ fontSize: 11, color: "var(--text-sub)", background: "var(--border)", borderRadius: 4, padding: "1px 6px" }}>{r.projectTitle}</span>
                  )}
                  <span style={{ fontSize: 13, fontWeight: 600, color: "var(--text-main)" }}>{highlight(r.threadTitle, query)}</span>
                </div>
                <div style={{ fontSize: 12, color: "var(--text-sub)", lineHeight: 1.5 }}>{highlight(r.matchContent, query)}</div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ImagesPlaceholder() {
  return (
    <div className="utility-view">
      <div className="utility-view__icon">▣</div>
      <div className="utility-view__title">{t("home.imagesTitle")}</div>
      <div className="utility-view__desc">{t("home.imagesDesc")}</div>
    </div>
  );
}

function HomeComposer({
  placeholder, isSending, onSubmit, attachedFiles, onAttachFiles
}: {
  placeholder: string;
  isSending: boolean;
  onSubmit: (value: string) => void;
  attachedFiles?: AttachedFile[];
  onAttachFiles?: (files: AttachedFile[]) => void;
}) {
  const [value, setValue] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);

  // 메뉴 외부 클릭 시 닫기
  useState(() => {
    function handleClick(e: MouseEvent) {
      if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  });

  function handleSubmit() {
    const trimmed = value.trim();
    if ((!trimmed && (!attachedFiles || attachedFiles.length === 0)) || isSending) return;
    onSubmit(trimmed);
    setValue("");
  }

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (files.length === 0) return;
    const maxSize = 20 * 1024 * 1024;
    const current = attachedFiles ?? [];
    const remaining = MAX_ATTACHMENTS - current.length;
    if (remaining <= 0) { showToast(t("chat.maxAttachments").replace("{max}", String(MAX_ATTACHMENTS)), "warning"); e.target.value = ""; return; }
    const toProcess = files.slice(0, remaining).filter(f => f.size <= maxSize);
    const results = await Promise.all(toProcess.map(file => new Promise<AttachedFile>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        const base64 = result.split(",")[1] ?? result;
        resolve({ name: file.name, type: file.type, base64, size: file.size });
      };
      reader.readAsDataURL(file);
    })));
    onAttachFiles?.([...current, ...results]);
    e.target.value = "";
  }

  return (
    <div
      className="launcher-composer"
      onDragOver={e => { e.preventDefault(); (e.currentTarget as HTMLElement).style.outline = "2px dashed var(--text-soft)"; }}
      onDragLeave={e => { (e.currentTarget as HTMLElement).style.outline = ""; }}
      onDrop={async e => {
        e.preventDefault();
        (e.currentTarget as HTMLElement).style.outline = "";
        const files = Array.from(e.dataTransfer.files ?? []);
        if (files.length === 0) return;
        const maxSize = 20 * 1024 * 1024;
        const current = attachedFiles ?? [];
        const remaining = MAX_ATTACHMENTS - current.length;
        if (remaining <= 0) { showToast(t("chat.maxAttachments").replace("{max}", String(MAX_ATTACHMENTS)), "warning"); return; }
        const toProcess = files.slice(0, remaining).filter(f => f.size <= maxSize);
        const results = await Promise.all(toProcess.map(file => new Promise<AttachedFile>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => {
            const result = reader.result as string;
            const base64 = result.split(",")[1] ?? result;
            resolve({ name: file.name, type: file.type, base64, size: file.size });
          };
          reader.readAsDataURL(file);
        })));
        onAttachFiles?.([...current, ...results]);
      }}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,.pdf,.txt,.md,.csv,.json,.ts,.tsx,.js,.jsx,.py"
        style={{ display: "none" }}
        multiple
        onChange={handleFileChange}
      />

      {/* 첨부 파일 미리보기 */}
      {attachedFiles && attachedFiles.length > 0 && (
        <div style={{ padding: "8px 14px 0", display: "flex", flexWrap: "wrap", gap: 8, alignItems: "flex-start" }}>
          {attachedFiles.map((f, idx) => (
            <FilePreviewThumbnail
              key={idx}
              name={f.name}
              type={f.type}
              base64={f.base64}
              size={f.size}
              onDelete={() => onAttachFiles?.(attachedFiles.filter((_, i) => i !== idx))}
            />
          ))}
          {attachedFiles.length < MAX_ATTACHMENTS && (
            <div style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: 80,
              height: 80,
              borderRadius: 10,
              border: "1px dashed var(--border)",
              background: "var(--surface-2)",
              fontSize: 11,
              color: "var(--text-soft)",
              fontWeight: 500,
              textAlign: "center"
            }}>
              {attachedFiles.length}/{MAX_ATTACHMENTS}
            </div>
          )}
        </div>
      )}

      <div className="launcher-composer__input-wrap">
        <div ref={menuRef} style={{ position: "relative" }}>
          <button
            type="button"
            className="launcher-composer__ghost"
            onClick={() => setMenuOpen(o => !o)}
            title={t("chat.tools")}
          >
            <PlusIcon />
          </button>

          {menuOpen && (
            <div style={{
              position: "absolute", left: 0, bottom: 40, zIndex: 60,
              width: 260, padding: 8, border: "1px solid var(--border)",
              borderRadius: 16, background: "#ffffff",
              boxShadow: "0 4px 20px rgba(0,0,0,0.10)",
              display: "flex", flexDirection: "column" as const, gap: 4
            }}>
              <button type="button" onClick={() => { fileInputRef.current?.click(); setMenuOpen(false); }}
                style={{ width: "100%", padding: "10px", borderRadius: 12, display: "flex", alignItems: "flex-start", gap: 10, border: "none", background: "none", cursor: "pointer", textAlign: "left" as const }}
                onMouseEnter={e => (e.currentTarget.style.background = "rgba(17,24,39,0.05)")}
                onMouseLeave={e => (e.currentTarget.style.background = "none")}>
                <span style={{ width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" /></svg>
                </span>
                <span>
                  <div style={{ fontSize: 14, fontWeight: 700, color: "var(--text-main)" }}>{t("chat.uploadFiles")}</div>
                  <div style={{ fontSize: 12, color: "var(--text-sub)", marginTop: 2 }}>{t("chat.uploadFilesDesc")}</div>
                </span>
              </button>
            </div>
          )}
        </div>
        <input
          value={value}
          onChange={e => setValue(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); handleSubmit(); } }}
          placeholder={attachedFiles && attachedFiles.length > 0 ? t("chat.placeholderWithFile") : placeholder}
          className="launcher-composer__input"
        />
        <div className="launcher-composer__actions">
          <button
            type="button"
            className="launcher-composer__submit"
            onClick={handleSubmit}
            disabled={isSending || (!value.trim() && !(attachedFiles && attachedFiles.length > 0))}
          >
            <WaveIcon />
          </button>
        </div>
      </div>
    </div>
  );
}

function GeneralHome({
  isSending, onSubmitPrompt, attachedFiles, onAttachFiles
}: {
  isSending: boolean;
  onSubmitPrompt: (value: string) => void;
  attachedFiles?: AttachedFile[];
  onAttachFiles?: (files: AttachedFile[]) => void;
}) {
  return (
    <div
      className="general-home"
      onDragOver={e => { e.preventDefault(); }}
      onDrop={async e => {
        e.preventDefault();
        const files = Array.from(e.dataTransfer.files ?? []);
        if (files.length === 0) return;
        const maxSize = 20 * 1024 * 1024;
        const current = attachedFiles ?? [];
        const remaining = MAX_ATTACHMENTS - current.length;
        if (remaining <= 0) { showToast(t("chat.maxAttachments").replace("{max}", String(MAX_ATTACHMENTS)), "warning"); return; }
        const toProcess = files.slice(0, remaining).filter(f => f.size <= maxSize);
        const results = await Promise.all(toProcess.map(file => new Promise<AttachedFile>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => {
            const result = reader.result as string;
            const base64 = result.split(",")[1] ?? result;
            resolve({ name: file.name, type: file.type, base64, size: file.size });
          };
          reader.readAsDataURL(file);
        })));
        onAttachFiles?.([...current, ...results]);
      }}
    >
      <div className="general-home__center" style={{ marginTop: "-30vh" }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginBottom: 24 }}>
          <img
            src="/corvus-logo.png"
            alt="CORVUS X"
            style={{ width: 160, height: 160, objectFit: "contain" }}
          />
        </div>
        <HomeComposer
          placeholder={t("chat.placeholderHome")}
          isSending={isSending}
          onSubmit={onSubmitPrompt}
          attachedFiles={attachedFiles}
          onAttachFiles={onAttachFiles}
        />
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 16, justifyContent: "center" }}>
          {[
            { cmd: "/research", label: t("home.deepResearch") },
            { cmd: "/legal", label: t("home.legalReview") },
            { cmd: "/finance", label: t("home.financeAnalysis") },
            { cmd: "/code", label: t("home.codeWrite") },
            { cmd: "/dalle", label: t("home.imageGen") },
          ].map(({ cmd, label }) => (
            <button
              key={cmd}
              type="button"
              onClick={() => onSubmitPrompt(cmd + " ")}
              style={{
                display: "inline-flex", alignItems: "center",
                padding: "6px 14px", borderRadius: 999,
                border: "1px solid var(--border)",
                background: "var(--bg-surface, #fefefe)",
                cursor: "pointer", fontSize: 13, fontWeight: 600,
                color: "var(--text-sub)",
                fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
                transition: "background 0.15s, border-color 0.15s"
              }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "var(--bg-soft)"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "var(--bg-surface, #fefefe)"; }}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function HomeView({
  workspaceKind, activeProject, generalThreads, projectThreads,
  sidebarView, isSending, onOpenThread, onSubmitPrompt,
  onRenameThread, onMoveThread, onRemoveFromProject, onDeleteThread, projectGroups,
  attachedFiles, onAttachFiles
}: Props) {
  if (sidebarView === "search") {
    return (
      <div className="home-view">
        <div className="home-view__scroll" style={{ display: "flex", flexDirection: "column" }}>
          <SearchView threads={[...generalThreads, ...projectThreads]} projectGroups={projectGroups} onOpenThread={onOpenThread} />
        </div>
      </div>
    );
  }
  if (sidebarView === "images") {
    return (
      <div className="home-view">
        <div className="home-view__scroll">
          <div className="home-view__inner utility-view__inner"><ImagesPlaceholder /></div>
        </div>
      </div>
    );
  }
  if (workspaceKind === "project") {
    return (
      <ProjectHomeView
        project={activeProject}
        activeThreadId={null}
        onOpenThread={onOpenThread}
        onRenameThread={onRenameThread ? (threadId: string) => onRenameThread(threadId, "") : undefined}
        onMoveThread={onMoveThread ? (threadId: string) => onMoveThread(threadId, "__general__") : undefined}
        onDeleteThread={onDeleteThread}
        onRemoveFromProject={onRemoveFromProject}
        onSubmitPrompt={onSubmitPrompt}
        isSending={isSending}
        attachedFiles={attachedFiles}
        onAttachFiles={onAttachFiles}
      />
    );
  }
  if (workspaceKind === "general") {
    return (
      <div className="home-view">
        <div className="home-view__scroll">
          <GeneralHome
            isSending={isSending}
            onSubmitPrompt={onSubmitPrompt}
            attachedFiles={attachedFiles}
            onAttachFiles={onAttachFiles}
          />
        </div>
      </div>
    );
  }
  return <div className="home-view" />;
}
